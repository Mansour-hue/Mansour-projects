<?php

$host="localhost";
$user="id14836199_ypc_admin1";
$password="cPYesabatad#1f";
$dbname="id14836199_ypc_database1";
//$db=mysqli_connect($host,$user,$password,$dbname);

//trigger exception in a "try" block
try {
  if(isset($_POST['name']))
{
    //echo "name is set";
}
if(isset($_POST['image']))
{
//echo "image is set";
}
if(isset($_POST['description']))
{
    //echo "type is set";
}
/*
if(isset($_POST['street']))
{
echo "street is set";
}
*/
//$pizza  = "piece1 piece2 piece3 piece4 piece5 piece6";
//$pieces = explode(" ", $pizza);
//echo $pieces[0]; // piece1
//echo $pieces[1]; // piece2

$conn=new PDO("mysql:host=$host;dbname=$dbname",$user,$password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//$sql1->set_charset("utf8mb4")
$Image = base64_decode($_POST['image']);
$TMP = $_POST['description'];
$TMPstring = explode("1111122222",$TMP);
$Type = $TMPstring[0];
$Name = $TMPstring[1];
$Street = $TMPstring[2];
$Device = $TMPstring[3];


$query = "INSERT INTO reports (name,image) VALUES(?,?)";
$sql1="INSERT INTO `reports`(`report_type`, `report_target`, `report_street`, `report_device_id`, `report_image`) VALUES(?,?,?,?,?)";
$statement=$conn->prepare($sql1);
$statement->execute(array($Type,$Name,$Street,$Device,$Image));
echo "تم الارسال بنجاح";
//$stmt=$conn->query($sql1);
}

//catch exception
catch(Exception $e) {
  echo 'Message: ' .$e->getMessage();
  echo "فشلت العملية";
}

//if($_SERVER['REQUEST_METHOD']=='POST'){

$stmt = null;

		//$image="";
		//$name="";
		//$Image = $_POST['image'];
		//$Name = $_POST['name'];
	//	$sql="INSERT INTO images_tbl (image,img_name) VALUES (?)";
	//	$stmt=mysqli_prepare($db,$sql);
	//	mysqli_stmt_bind_param($stmt,"s",$image);
	//	$stms.mysqli_stmt_execute($stmt);
	//	$check=mysqli_stmt_affected_rows($stmt);
	//	if($check==1){
	//		echo "Image Uploaded Successfully";
	//	}else{
	//		echo "Error Uploading Image";
	//	}
	//	mysqli_close($db);
//	}else{
//		echo "Error";
//	}
?>