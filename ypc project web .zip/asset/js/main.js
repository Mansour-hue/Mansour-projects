$(document).ready(function() {
	$overHeight = $('.overlay').parent().height();
	$('.overlay').height($overHeight);
});
