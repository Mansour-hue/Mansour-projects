<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Stations extends CI_Controller
{

    /**  __construct function  */
    // --------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Station_model', 'stationModel');
    }

    /**  Index function  */
    // --------------------------------------------------------------------------------------------------
    public function index()
    {
        $data = [];
        $data['title'] = 'المحطات';
        $data['view'] = 'station/station_view';
        $data['station_data'] = $this->stationModel->get_all_stations();
        $this->load->view('layout/layout', $data);
    }

    /**  Add station Function  */
    // --------------------------------------------------------------------------------------------------
    public function add_station()
    {
        $data = [];
        $data['page_title'] = 'Add_station';
        $data['edit'] = 0;
        $data['view'] = 'station/station_form_view';

        if($_POST){
            


            # XSS Filtering
            $_POST = $this->security->xss_clean($_POST);

            # Form Validation
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', 'Station Name', 'trim|required');
            $this->form_validation->set_rules('s_type', 'Station type', 'trim|required');
            $this->form_validation->set_rules('s_status', 'Station Status', 'trim|required');
            $this->form_validation->set_rules('s_address', 'Station Address', 'trim|required');
            $this->form_validation->set_rules('s_latitude', 'Station Latitude', 'trim|required');
            $this->form_validation->set_rules('s_longitude', 'Station Longitude', 'trim|required');
            $this->form_validation->set_rules('s_longitude', 'Station Longitude', 'trim|required');


            if ($this->form_validation->run() == false) {
                $data['name'] = $this->input->post('name');
                $data['s_type'] = $this->input->post('s_type');
                $data['s_status'] = $this->input->post('s_status');
                $data['s_address'] = $this->input->post('s_address');
                $data['s_latitude'] = $this->input->post('s_latitude');
                $data['s_longitude'] = $this->input->post('s_longitude');
                // var_dump($_POST);exit();

            } else {

                $insert_data = [
                    's_name' => $this->input->post('name'),
                    's_type' => $this->input->post('s_type'),
                    's_status' => $this->input->post('s_status'),
                    's_address' => $this->input->post('s_address'),
                    's_latitude' => $this->input->post('s_latitude'),
                    's_longitude' => $this->input->post('s_longitude')
                    

                ];

                // Insert User in Database
                
                $host="localhost";
                $user="id14836199_ypc_admin1";
                $password="cPYesabatad#1f";
                $dbname="id14836199_ypc_database1";
                
                $conn=new PDO("mysql:host=$host;dbname=$dbname",$user,$password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                $sql1 = "INSERT INTO `notifications`(`n_item`, `n_message`) VALUES (?,?)";
                $statement=$conn->prepare($sql1);
                //$statement->execute();
                $statement->execute(array($this->input->post('name'),'تم اضافة محطة جديدة'));
				
                $output = $this->stationModel->insert_station($insert_data);
                if(!empty($output) and $output > 0) {
                    // Success Add Message
                    $this->session->set_flashdata('success_add', 'station has been added successfuly');
                    redirect(base_url('Stations/index'));
                } 
                else {
                    // Error
                    $this->session->set_flashdata('error_add', 'Sorry There was an error!');
                }

            }

        }
        $this->load->view('layout/layout', $data);
    }

    /** Edit station function */
    // --------------------------------------------------------------------------------------------------
    public function edit_station($station_id)
    {
        $data = [];
        $data['title'] = 'Edit_station';
        $data['edit'] = 1;
        $data['view'] = 'station/station_form_view';

        $data['station'] = $this->stationModel->get_station($station_id);


        if ($_POST) {

            # XSS Filtering
            $_POST = $this->security->xss_clean($_POST);

            # Form Validation
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->form_validation->set_rules('s_type', 'Station type', 'trim|required');
            $this->form_validation->set_rules('s_status', 'Station Status', 'trim|required');
            $this->form_validation->set_rules('s_address', 'Station Address', 'trim|required');
            $this->form_validation->set_rules('s_latitude', 'Station Latitude', 'trim|required');
            $this->form_validation->set_rules('s_longitude', 'Station Longitude', 'trim|required');

            if ($this->form_validation->run() == false) {
                $data['name'] = $this->input->post('name');
            } else {
                $new_data['s_name'] = $this->input->post('name');
                $new_data['s_type'] = $this->input->post('s_type');
                $new_data['s_status'] = $this->input->post('s_status');
                $new_data['s_address'] = $this->input->post('s_address');
                $new_data['s_latitude'] = $this->input->post('s_latitude');
                $new_data['s_longitude'] = $this->input->post('s_longitude');

                // var_dump($new_data, $station_id);exit();

                // Update User in Database
                $host="localhost";
                $user="id14836199_ypc_admin1";
                $password="cPYesabatad#1f";
                $dbname="id14836199_ypc_database1";
                
                $conn=new PDO("mysql:host=$host;dbname=$dbname",$user,$password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                $sql1 = "INSERT INTO `notifications`(`n_item`, `n_message`) VALUES (?,?)";
                $statement=$conn->prepare($sql1);
                //$statement->execute();
                $statement->execute(array($this->input->post('name'),'تم تعديل بيانات محطة'));
				
                $output = $this->stationModel->update_station($station_id, $new_data);
                
                if (!empty($output) and $output > 0) {
                    // Success Message
                    $this->session->set_flashdata('updated', 'station has been updated successfuly');
                    redirect(base_url('Stations/index'));
                } else {
                    // Error Message
                    $this->session->set_flashdata('error_update', 'Sorry There was an error! on update');
                    $new_data['order'] = $this->input->post('order');
                }
            }

        }
        $this->load->view('layout/layout', $data);
    }

    /** Delete station function */
    // --------------------------------------------------------------------------------------------------
    public function delete_station($id)
    {
		$this->stationModel->delete_station($id);
		
		$this->session->set_flashdata('deleted', 'station has been DELETED');
        redirect(base_url('stations/index'));
    }
  
}
