<?php
defined('BASEPATH') or exit('No direct script access allowed');

class News extends CI_Controller
{

    /**  __construct function  */
    // --------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct();
        $this->load->model('news_model', 'newsModel');
    }

    /**  Index function  */
    // --------------------------------------------------------------------------------------------------
    public function index()
    {
        $data = [];
        $data['title'] = 'News';
        $data['view'] = 'new/news_view';
        $data['news_data'] = $this->newsModel->get_all_news();
        $this->load->view('layout/layout', $data);
    }

    /**  Add Function  */
    // --------------------------------------------------------------------------------------------------

    public function add_news()
    {
        $data = [];
        $data['page_title'] = 'add_news';
        $data['edit'] = 0;
        $data['view'] = 'new/news_form_view';

        $error = '';

        # XSS Filtering
        $_POST = $this->security->xss_clean($_POST);

        # Form Validation
        $this->load->library('form_validation');
        $this->form_validation->set_rules('n_title', 'Title', 'trim|required');
        $this->form_validation->set_rules('n_content', 'News Content', 'trim|required');
        
        if ($_POST) {
			$data['n_title'] = $this->input->post('n_title');
            $data['n_content'] = $this->input->post('n_content');

            
            }
            if ($this->form_validation->run() == false) {
				$data['n_title'] = $this->input->post('n_title');
                $data['n_content'] = $this->input->post('n_content');
            } else {
				$insert_data = [
                    'n_title' => $this->input->post('n_title'),
                    'n_content' => $this->input->post('n_content'),
                ];
				
				$host="localhost";
                $user="id14836199_ypc_admin1";
                $password="cPYesabatad#1f";
                $dbname="id14836199_ypc_database1";
                
                $conn=new PDO("mysql:host=$host;dbname=$dbname",$user,$password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                $sql1 = "INSERT INTO `notifications`(`n_item`, `n_message`) VALUES (?,?)";
                $statement=$conn->prepare($sql1);
                //$statement->execute();
                $statement->execute(array($this->input->post('n_title'),'تم اضافة خبر جديد'));
				
                // Insert in Database
                $output = $this->newsModel->insert_news($insert_data);
                if ($output == true) {
                    // Success Add Message
                    $this->session->set_flashdata('success_add', 'news has been added successfuly');
                    redirect(base_url('News/index'));
                } else {
                    // Error
                    $this->session->set_flashdata('error_add', 'Sorry There was an error!');
                }
            
        }
        $this->load->view('layout/layout', $data);
    }

    /** Edit function */
    // --------------------------------------------------------------------------------------------------
    public function edit_news($id)
    {
        $data = [];
        $data['title'] = 'edit_news';
        $data['edit'] = 1;
        $data['view'] = 'new/news_form_view';
		$data['news'] = $this->newsModel->get_news($id);
		
        # XSS Filtering
        $_POST = $this->security->xss_clean($_POST);

        # Form Validation
        $this->load->library('form_validation');
        $this->form_validation->set_rules('n_title', 'Title', 'trim|required');
        $this->form_validation->set_rules('n_content', 'News Content', 'trim|required');

        if ($_POST) {
			$new_data = [];
            $new_data['n_title'] = $this->input->post('n_title');
            $new_data['n_content'] = $this->input->post('n_content');
            }
            if ($this->form_validation->run() == false) {
                $data['n_title'] = $this->input->post('n_title');
                $data['n_content'] = $this->input->post('n_content');
			} 
			else
			{
				// var_dump($new_data);exit;
				// Update in Database
				$output = $this->newsModel->update_news($id, $new_data);
				if ($output == true) {
                    // Success Message
                    $this->session->set_flashdata('updated', 'news has been updated successfuly');
                    redirect(base_url('News/index'));
                } else {
                    // Error Message
                    $this->session->set_flashdata('error_update', 'Sorry There was an error! on update');
                }
            
        }
        $this->load->view('layout/layout', $data);
    }

    /** Delete nav function */
    // --------------------------------------------------------------------------------------------------
    public function delete_news($id)
    {
		$this->newsModel->delete_news($id);
		$this->session->set_flashdata('deleted', 'news has been DELETED');
        redirect(base_url('News/index'));
    }
}
