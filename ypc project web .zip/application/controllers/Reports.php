<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Reports extends CI_Controller
{

    /**  __construct function  */
    // --------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Reports_model', 'ReportsModel');
    }

    /**  Index function  */
    // --------------------------------------------------------------------------------------------------
    public function index()
    {
        // $sess_data = $this->session->has_userdata('id');
        // var_dump($sess_data);exit;

        $data = [];
        $data['title'] = 'Reports';
        $data['view'] = 'reports/reports_view';
        $data['reports_data'] = $this->ReportsModel->get_all_reports();
        $this->load->view('layout/layout', $data);
    }

    /**  Add Function  */
    // --------------------------------------------------------------------------------------------------

    // public function add_report()
    // {
    //     $data = [];
    //     $data['page_title'] = 'Add_report';
    //     $data['edit'] = 0;
    //     $data['view'] = 'reports/reports_form_view';

    //     # XSS Filtering
    //     $_POST = $this->security->xss_clean($_POST);

    //     # Form Validation
    //     $this->load->library('form_validation');
    //     $this->form_validation->set_rules('R_type', 'R_type', 'trim|required');
    //     $this->form_validation->set_rules('R_description', 'Description', 'trim|required');
    //     $this->form_validation->set_rules('R_time', 'R time', 'trim');
    //     $this->form_validation->set_rules('R_Date', 'R Date', 'trim|required');
    //     $this->form_validation->set_rules('R_description', 'Description', 'trim|required');
    //     if (empty($_FILES['verification_picture']['name'])) {
    //         $this->form_validation->set_rules('verification_picture', 'Image', '|required');
    //     }

    //     if ($_POST) {
    //         $data['R_type'] = $this->input->post('R_type');
    //         $data['R_description'] = $this->input->post('R_description');
    //         $data['R_time'] = $this->input->post('R_time');
    //         $data['R_Date'] = $this->input->post('R_Date');
    //         $data['R_time'] = $this->input->post('R_time');


    //         // Upload image
    //         if ($_FILES['img']) {
    //             $config['upload_path'] = APPPATH . '../files/imgs/reports images/';
    //             $config['allowed_types'] = 'gif|jpg|png|webp|tiff|psd|raw|bmp|heif|inddjpeg';
    //             $config['max_size'] = 0;
    //             // $config['max_width'] = 1000;
    //             // $config['max_height'] = 1000;

    //             $this->load->library('upload', $config);
    //             $upload_process = $this->upload->do_upload('verification_picture');

    //             if ($upload_process == false) {
    //                 $img_err = $this->upload->display_errors();
    //             } else {
    //                 $img = $this->upload->data();
    //                 $image_name = $img['file_name'];
    //             }
    //         }
    //         if ($this->form_validation->run() == false || isset($img_err)) {
    //             $data['R_type'] = $this->input->post('R_type');
    //             $data['R_description'] = $this->input->post('R_description');
    //             $data['R_time'] = $this->input->post('R_time');
    //             $data['R_Date'] = $this->input->post('R_Date');
    //             $data['R_time'] = $this->input->post('R_time');

    //             $data['img_err'] = $img_err;
    //         } else {
    //             $insert_data = [
    //                 'verification_picture' => $image_name,
    //                 'R_type' => $this->input->post('R_type'),
    //                 'R_description' => $this->input->post('R_description'),
    //                 'R_time' => $this->input->post('R_time'),
    //             ];

    //             // Insert in Database
    //             $output = $this->ReportsModel->insert_reports($insert_data);
    //             if ($output == true) {
    //                 // Success Add Message
    //                 $this->session->set_flashdata('success_add', 'Reports has been added successfuly');
    //                 redirect(base_url('Reports/index'));
    //             } else {
    //                 // Error
    //                 $this->session->set_flashdata('error_add', 'Reports There was an error!');
    //             }
    //         }
    //     }
    //     $this->load->view('layout/layout', $data);
    // }

    /** Edit function */
    // --------------------------------------------------------------------------------------------------
    // public function edit_report($id)
    // {
    //     $data = [];
    //     $data['title'] = 'Edit_work';
    //     $data['edit'] = 1;
    //     $data['view'] = 'works/works_form_view';
    //     $data['work'] = $this->ReportsModel->get_work($id);

    //     # XSS Filtering
    //     $_POST = $this->security->xss_clean($_POST);

    //     # Form Validation
    //     $this->load->library('form_validation');
    //     $this->form_validation->set_rules('title', 'Title', 'trim');
    //     $this->form_validation->set_rules('description', 'Description', 'trim');
    //     $this->form_validation->set_rules('order', 'Order', 'trim');

    //     if ($_POST) {
    //         $new_data = [];
    //         $new_data['title'] = $this->input->post('title');
    //         $new_data['description'] = $this->input->post('description');
    //         $new_data['order'] = $this->input->post('order');
    //         $new_data['img'] = $data['work']->img;

    //         // var_dump($_POST, $_FILES);exit;
    //         // Upload image
    //         if ($_FILES['img']['size'] > 0) {
    //             $config['upload_path'] = APPPATH . '../files/imgs/works images/';
    //             $config['allowed_types'] = 'gif|jpg|png|webp|tiff|psd|raw|bmp|heif|inddjpeg';
    //             $config['max_size'] = 0;
    //             // $config['max_width'] = 1000;
    //             // $config['max_height'] = 1000;

    //             $this->load->library('upload', $config);
    //             $upload_process = $this->upload->do_upload('img');

    //             if ($upload_process == false) {
    //                 $img_err = $this->upload->display_errors();
    //             } else {
    //                 $img = $this->upload->data();
    //                 $image_name = $img['file_name'];
    //                 $new_data['img'] = $image_name;
    //             }
    //         }

    //         if ($this->form_validation->run() == false || isset($img_err)) {
    //             $data['title'] = $this->input->post('title');
    //             $data['description'] = $this->input->post('description');
    //             $data['order'] = $this->input->post('order');
    //             $data['img_err'] = $img_err;
    //         } else {
    //             // Update in Database
    //             $output = $this->ReportsModel->update_work($id, $new_data);
    //             if ($output == true) {
    //                 // Success Message
    //                 $this->session->set_flashdata('updated', 'Work has been updated successfuly');
    //                 redirect(base_url('works/index'));
    //             } else {
    //                 // Error Message
    //                 $this->session->set_flashdata('error_update', 'Sorry There was an error! on update');
    //             }
    //         }
    //     }
    //     $this->load->view('layout/layout', $data);
    // }

    /** Vivew img on site function */
    // --------------------------------------------------------------------------------------------------
  //   public function view_onsite()
  //   {
		// //var_dump($_POST);exit;
		// if (isset($_POST['view']) && isset($_POST['workID'])) {
			
		// 	$workID = $this->input->post('workID');
		// 	$view = $this->input->post('view');
			
		// 	if($view == 1 || $view == 0 )
		// 	{
		// 		$this->ReportsModel->view_onsite($workID, $view);
		// 	} 
		// 	else
		// 	{
  //               echo "Sorry There was an error.";
		// 	}
		// }
  //   }

    /** Delete function */
    // --------------------------------------------------------------------------------------------------
    public function delete_report($id)
    {
        $this->ReportsModel->delete_reports($id);

        $this->session->set_flashdata('deleted', 'report has been DELETED');
        redirect(base_url('Reports/index'));
    }

}
