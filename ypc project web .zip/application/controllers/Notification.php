<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Notification extends CI_Controller
{

    /**  __construct function  */
    // --------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct();
        $this->load->model('notification_model', 'NotificationModel');
    }

    /**  Index function  */
    // --------------------------------------------------------------------------------------------------
    public function index()
    {
        $data = [];
        $data['title'] = 'News';
        $data['view'] = 'notification/notification_view';
        $data['notification_data'] = $this->NotificationModel->get_all_notifications();
        $this->load->view('layout/layout', $data);
    }

    /**  Add Function  */
    // --------------------------------------------------------------------------------------------------

    public function add_notification()
    {
        $data = [];
        $data['page_title'] = 'add_news';
        $data['edit'] = 0;
        $data['view'] = 'notification/notification_form_view';

        $error = '';

        # XSS Filtering
        $_POST = $this->security->xss_clean($_POST);

        # Form Validation
        $this->load->library('form_validation');
        $this->form_validation->set_rules('n_item', 'notification item', 'trim|required');
        $this->form_validation->set_rules('n_message', 'notification message', 'trim|required');
   
        if ($_POST) {
			$data['n_item'] = $this->input->post('n_item');
            $data['n_message'] = $this->input->post('n_message');

          
            if ($this->form_validation->run() == false) {
				$data['n_item'] = $this->input->post('n_item');
                $data['n_message'] = $this->input->post('n_message');
            } else {
				$insert_data = [
                    'n_item' => $this->input->post('n_item'),
                    'n_message' => $this->input->post('n_message')
                ];
				
                // Insert in Database
                $output = $this->NotificationModel->insert_notifications($insert_data);
                if ($output == true) {
                    // Success Add Message
                    $this->session->set_flashdata('success_add', 'Notification has been added successfuly');
                    redirect(base_url('Notification/index'));
                } else {
                    // Error
                    $this->session->set_flashdata('error_add', 'Sorry There was an error!');
                }
            }
        }
        $this->load->view('layout/layout', $data);
    }

    /** Edit function */
    // --------------------------------------------------------------------------------------------------
    public function edit_notification($id)
    {
        $data = [];
        $data['title'] = 'edit_news';
        $data['edit'] = 1;
        $data['view'] = 'notification/notification_form_view';
		$data['notification'] = $this->NotificationModel->get_notifications($id);
		
        # XSS Filtering
        $_POST = $this->security->xss_clean($_POST);

        # Form Validation
        $this->load->library('form_validation');
        $this->form_validation->set_rules('n_item', 'notification item', 'trim|required');
        $this->form_validation->set_rules('n_message', 'notification message', 'trim|required');

        if ($_POST) {

			$new_data = [];
            $new_data['n_item'] = $this->input->post('n_item');
            $new_data['n_message'] = $this->input->post('n_message');

            if ($this->form_validation->run() == false) {
                $data['n_item'] = $this->input->post('n_item');
                $data['n_message'] = $this->input->post('n_message');
			} 
			else
			{
				// var_dump($new_data);exit;
				// Update in Database
				$output = $this->NotificationModel->update_notifications($id, $new_data);
				if ($output == true) {
                    // Success Message
                    $this->session->set_flashdata('updated', 'notification has been updated successfuly');
                    redirect(base_url('Notification/index'));
                } else {
                    // Error Message
                    $this->session->set_flashdata('error_update', 'Sorry There was an error! on update');
                }
            }
        }
        $this->load->view('layout/layout', $data);
    }

    /** Delete nav function */
    // --------------------------------------------------------------------------------------------------
    public function delete_notification($id)
    {
		$this->NotificationModel->delete_notifications($id);
		$this->session->set_flashdata('deleted', 'news has been DELETED');
        redirect(base_url('Notification/index'));
    }
}
