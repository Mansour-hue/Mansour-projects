<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Persons extends MY_Controller
{

    /**  __construct function  */
    // --------------------------------------------------------------------------------------------------
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Persons_model', 'PersonsModel');
    }

    /**  Index function  */
    // --------------------------------------------------------------------------------------------------
    public function index()
    {
        $data = [];
        $data['title'] = 'Users';
        $data['view'] = 'person/person_view';
        $data['persons_data'] = $this->PersonsModel->get_all_persons();
        $this->load->view('layout/layout', $data);
    }

    /**  Add station Function  */
    // --------------------------------------------------------------------------------------------------
    public function add_person()
    {
        $data = [];
        $data['page_title'] = 'add user';
        $data['edit'] = 0;
        $data['view'] = 'person/person_form_view';

        # XSS Filtering
        $_POST = $this->security->xss_clean($_POST);

        # Form Validation
        $this->load->library('form_validation');
        $this->form_validation->set_rules('Fname', ' Fname ', 'trim|required');
        $this->form_validation->set_rules('Lname', 'Lname', 'trim|required');
        $this->form_validation->set_rules('U_password', 'Uesr Password', 'trim|required');
        $this->form_validation->set_rules('Email', 'User Email', 'trim|required');

        if ($this->form_validation->run() == false) {
            $data['Fname'] = $this->input->post('Fname');
            $data['Lname'] = $this->input->post('Lname');
            $data['U_password'] = $this->input->post('U_password');
            $data['Email'] = $this->input->post('Email');

        } else {
            $insert_data = [
                'Fname' => $this->input->post('Fname'),
                'Lname' => $this->input->post('Lname'),
                'U_password' => $this->input->post('U_password'),
                'Email' => $this->input->post('Email'),
                'M_ID' => $this->input->post('M_ID')
            ];
            // Insert User in Database
            $output = $this->PersonsModel->insert_persons($insert_data);
            if (!empty($output) and $output > 0) {
                // Success Add Message
                $this->session->set_flashdata('success_add', 'User has been added successfuly');
                redirect(base_url('Persons/index'));
            } else {
                // Error
                $this->session->set_flashdata('error_add', 'Sorry There was an error!');
            }
        }
        $this->load->view('layout/layout', $data);
    }

    /** Edit station function */
    // --------------------------------------------------------------------------------------------------
    public function edit_person($Persons)
    {
        $data = [];
        $data['title'] = 'edit person';
        $data['edit'] = 1;
        $data['view'] = 'person/person_form_view';

        $data['person'] = $this->PersonsModel->get_persons($Persons);


        if ($_POST) {

            # XSS Filtering
            $_POST = $this->security->xss_clean($_POST);

            # Form Validation
            $this->load->library('form_validation');
            $this->form_validation->set_rules('Fname', 'Fname', 'trim|required');
            $this->form_validation->set_rules('Lname', 'Lname', 'trim|required');
            $this->form_validation->set_rules('U_password', 'User password', 'trim|required');
            $this->form_validation->set_rules('Email', 'User Email', 'trim|required');

            $new_data['Fname'] = $this->input->post('Fname');
            $new_data['Lname'] = $this->input->post('Lname');
            $new_data['U_password'] = $this->input->post('U_password');
            $new_data['Email'] = $this->input->post('Email');
            $new_data['M_ID'] = $this->input->post('M_ID');

            if ($this->form_validation->run() == false) {
                $data['Fname'] = $this->input->post('Fname');
            } else {
                // Update User in Database
                $output = $this->PersonsModel->update_persons($Persons, $new_data);
                if (!empty($output) and $output > 0) {
                    // Success Message
                    $this->session->set_flashdata('success_update', 'User has been updated successfuly');
                    redirect(base_url('Persons/index'));
                } else {
                    // Error Message
                    $this->session->set_flashdata('error_update', 'Sorry There was an error! on update');
                    $new_data['order'] = $this->input->post('order');
                }
            }

        }
        $this->load->view('layout/layout', $data);
    }

    /** Delete person function */
    // --------------------------------------------------------------------------------------------------
    public function delete_person($id)
    {
        $this->PersonsModel->delete_person($id);
        
        $this->session->set_flashdata('deleted', 'user has been DELETED');
        redirect(base_url('Persons/index'));
    }
}
