<?php

class notification_model extends CI_Model
{

    /**  Get all function  */
    // --------------------------------------------------------------------------------------------------
	public function get_all_notifications(){
		$notifications = $this->db->get('notifications');
		return $notifications->result();
	}

    /**  Get One function  */
    // --------------------------------------------------------------------------------------------------
	public function get_notifications($id){
		$notifications = $this->db->get_where('notifications', ['n_id' => $id]);
		return $notifications->row();
	}

    /**  Insert function  */
    // --------------------------------------------------------------------------------------------------
	public function insert_notifications($data){
		$this->db->insert('notifications', $data);
		return $this->db->insert_id();
	}

    /**  Update function  */
    // --------------------------------------------------------------------------------------------------
	public function update_notifications($id, $new_data){
        // Check Service exist with id
        $query = $this->db->get_where('notifications', ['n_id' =>  $id] );

        if ($this->db->affected_rows() > 0) {
            
            // Update User
            $update_data = [
                'n_item' =>  $new_data['n_item'],
                'n_message' =>  $new_data['n_message']
            ];

            return $this->db->update('notifications', $update_data, ['n_id' => $query->row('n_id')]);
        }
        return false;
	}

	    /**  Delete function  */
    // --------------------------------------------------------------------------------------------------
    public function delete_notifications($id)
    {
		$this->db->delete('notifications', ['n_id'=>$id]);
    }
}


