<?php

class Station_model extends CI_Model
{

    /**  Get all stations function  */
    // --------------------------------------------------------------------------------------------------
	public function get_all_stations(){
		$stations = $this->db->get('station');
		return $stations->result();
	}

    /**  Get One station function  */
    // --------------------------------------------------------------------------------------------------
	public function get_station($id){
		$the_station = $this->db->get_where('station', ['s_id' => $id]);
		return $the_station->row();
	}

    /**  Insert function  */
    // --------------------------------------------------------------------------------------------------
	public function insert_station($data){
		$this->db->insert('station', $data);
		return $this->db->insert_id();
	}

    /**  Update function  */
    // --------------------------------------------------------------------------------------------------
	public function update_station($id, $new_data){
        // Check station exist with station_id
        $query = $this->db->get_where('station', ['s_id' =>  $id] );

        if ($this->db->affected_rows() > 0) {
            
            // Update
            $update_data = [
                's_name' =>  $new_data['s_name'],
                's_type' =>  $new_data['s_type'],
                's_status' =>  $new_data['s_status'],
                's_address' =>  $new_data['s_address'],
                's_latitude' =>  $new_data['s_latitude'],
                's_longitude' =>  $new_data['s_longitude']
            ];

            return $this->db->update('station', $update_data, ['s_id' => $query->row('s_id')]);
        }
        return false;
	}

    /**  Delete function  */
    // --------------------------------------------------------------------------------------------------
    public function delete_station($id)
    {
		$this->db->delete('station', ['s_id'=>$id]);
    }

}


