<?php

class Pricequantity_model extends CI_Model
{

    /**  Get all function  */
    // --------------------------------------------------------------------------------------------------
	public function get_all_pricequantity(){
		$pricequantity = $this->db->get('pricequantity');
		return $pricequantity->result();
	}

    /**  Get One function  */
    // --------------------------------------------------------------------------------------------------
	public function get_pricequantity($id){
		$pricequantity = $this->db->get_where('pricequantity', ['pq_id' => $id]);
		return $pricequantity->row();
	}

    /**  Insert function  */
    // --------------------------------------------------------------------------------------------------
	// public function insert_pricequantity($data){
	// 	$this->db->insert('pricequantity', $data);
	// 	return $this->db->insert_id();
	// }

    /**  Update function  */
    // --------------------------------------------------------------------------------------------------
	public function update_pricequantity($id, $new_data){
        // Check Service exist with id
        $query = $this->db->get_where('pricequantity', ['pq_id' =>  $id] );

        if ($this->db->affected_rows() > 0) {
            
            // Update User
            $update_data = [
                'pq_value' =>  $new_data['pq_value']
            ];

            return $this->db->update('pricequantity', $update_data, ['pq_id' => $query->row('pq_id')]);
        }
        return false;
	}

	    /**  Delete function  */
    // --------------------------------------------------------------------------------------------------
//     public function delete_pricequantity($id)
//     {
// 		$this->db->delete('pricequantity', ['pricequantity_ID'=>$id]);
//     }
}


