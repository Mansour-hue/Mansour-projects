<?php

class news_model extends CI_Model
{

    /**  Get all function  */
    // --------------------------------------------------------------------------------------------------
	public function get_all_news(){
		$news = $this->db->get('news');
		return $news->result();
	}

    /**  Get One function  */
    // --------------------------------------------------------------------------------------------------
	public function get_news($id){
		$news = $this->db->get_where('news', ['n_id' => $id]);
		return $news->row();
	}

    /**  Insert function  */
    // --------------------------------------------------------------------------------------------------
	public function insert_news($data){
		$this->db->insert('news', $data);
		return $this->db->insert_id();
	}

    /**  Update function  */
    // --------------------------------------------------------------------------------------------------
	public function update_news($id, $new_data){
        // Check Service exist with id
        $query = $this->db->get_where('news', ['n_id' =>  $id] );

        if ($this->db->affected_rows() > 0) {
            
            // Update User
            $update_data = [
                'n_title' =>  $new_data['n_title'],
                'n_content' =>  $new_data['n_content'],
            ];

            return $this->db->update('news', $update_data, ['n_id' => $query->row('n_id')]);
        }
        return false;
	}

	    /**  Delete function  */
    // --------------------------------------------------------------------------------------------------
    public function delete_news($id)
    {
		$this->db->delete('news', ['n_id'=>$id]);
    }
}


