<?php

class Reports_model extends CI_Model
{

    /**  Get all function  */
    // --------------------------------------------------------------------------------------------------
	public function get_all_reports(){
		$reports = $this->db->get('reports');
		return $reports->result();
	}

    /**  Get One function  */
    // --------------------------------------------------------------------------------------------------
	public function get_reports($id){
		$reports = $this->db->get_where('reports', ['report_id' => $id]);
		return $reports->row();
	}

    /**  Insert function  */
    // --------------------------------------------------------------------------------------------------
	// public function insert_reports($data){
	// 	$this->db->insert('Report', $data);
	// 	return $this->db->insert_id();
	// }

    /**  Update function  */
    // --------------------------------------------------------------------------------------------------
	// public function update_reports($id, $new_data){
 //        // Check work exist with id
 //        $query = $this->db->get_where('Report', ['R_ID' =>  $id] );

 //        if ($this->db->affected_rows() > 0) {
            
 //            // Update User
 //            $update_data = [
 //                'R_description' =>  $new_data['R_description'],
 //                'R_time' =>  $new_data['R_time'],
 //                'verification_picture' =>  $new_data['verification_picture'],
 //                'R_type' =>  $new_data['R_type'],
 //            ];

 //            return $this->db->update('Report', $update_data, ['R_ID' => $query->row('R_ID')]);
 //        }
 //        return false;
	// }

	/****  View work on site */
	//--------------------------------------------------------------------------------------------------
	// public function view_onsite($workID, $view)
	// {
	// 	$query = $this->db->get_where('Report', ['R_ID' =>  $workID] );

 //        if ($this->db->affected_rows() > 0) {
            
 //            // Update User
 //            $update_data = [
 //                'view' =>  $view
 //            ];

 //            return $this->db->update('Report', $update_data, ['R_ID' => $query->row('R_ID')]);
 //        }
	// }

	    /**  Delete function  */
    // --------------------------------------------------------------------------------------------------
    public function delete_reports($id)
    {
		$this->db->delete('reports', ['report_id'=>$id]);
    }
}


