<?php

class Persons_model extends CI_Model
{

    /**  Get all persons function  */
    // --------------------------------------------------------------------------------------------------
    public function get_all_persons(){
        $persons = $this->db->get('user');
        return $persons->result();
    }

    /**  Get One station function  */
    // --------------------------------------------------------------------------------------------------
    public function get_persons($id){
        $the_person = $this->db->get_where('user', ['U_ID' => $id]);
        return $the_person->row();
    }

    /**  Insert function  */
    // --------------------------------------------------------------------------------------------------
    public function insert_persons($data){
        $this->db->insert('user', $data);
        return $this->db->insert_id();
    }

    /**  Update function  */
    // --------------------------------------------------------------------------------------------------
    public function update_persons($id, $new_data){
        // Check station exist with station_id
        $query = $this->db->get_where('user', ['U_ID' =>  $id] );

        if ($this->db->affected_rows() > 0) {
            
            // Update
            $update_data = [
                'Fname' =>  $new_data['Fname'],
                'Lname' =>  $new_data['Lname'],
                'U_password' =>  $new_data['U_password'],
                'Email' =>  $new_data['Email'],
                'M_ID' =>  $new_data['M_ID'],
                'U_ID' =>  $new_data['U_ID']
            ];

            return $this->db->update('user', $update_data, ['U_ID' => $query->row('U_ID')]);
        }
        return false;
    }

    /**  Delete function  */
    // --------------------------------------------------------------------------------------------------
    public function delete_station($id)
    {
        $this->db->delete('user', ['U_ID'=>$id]);
    }

}


