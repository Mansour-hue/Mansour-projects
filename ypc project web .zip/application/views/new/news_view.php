
<?php if (null !== $this->session->flashdata('success_add')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('success_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
	<?php elseif (null !== $this->session->flashdata('updated')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('updated'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('error_add')): ?>
	<div class="alert alert-warning  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('error_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('deleted')): ?>
	<div class="alert alert-danger  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('deleted'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php endif;?>

<h2 class="text-center py-3">الاخبار </h2>
<a href='<?php echo base_url('news/add_news') ?>' class="btn btn-primary mb-2">اضافة اخبار</a>

<table class="table table-dark text-center">
<thead>
	<tr>
	    <th scope="col">رقم الادمن</th>
		<th scope="col">عنوان الخبر</th>
		<th scope="col">محتوى الخبر</th>
		<th scope="col">الصلاحيات</th>
	</tr>
</thead>
<tbody>
	<?php foreach ($news_data as $new): ?>
    <tr>
      <td style="max-width:150px;"><?=$new->m_id;?></td>
      <td style="max-width:150px;"><?=$new->n_title;?></td>
      <td style="max-width:450px;"><?=$new->n_content;?></td>
    <td>
      	<a href="<?php echo base_url() . 'News/edit_news/' . $new->n_id ?>" class="btn btn-success">تعديل</a>
        <a href="<?php echo base_url() . 'News/delete_news/' . $new->n_id ?>" class="btn btn-danger">حذف</a>
      </td>
    </tr>
	<?php endforeach;?>
 