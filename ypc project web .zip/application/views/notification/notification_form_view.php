
<div class="text-center w-100 mb-5">
    <h1 class="py-4"><?php echo $edit == '1' ? 'تعديل خبر' : 'اضافة خبر' ?></h1>
</div>
<div class="w-75 m-auto">
    <?php echo form_open_multipart( $edit == 1 ? base_url('Notification/edit_notification/'. $notification->n_id) : base_url('Notification/add_notification') );?>
        <div class="nav-form">
            <div class="form-group row">
                <label class="col-md-2 text-right " for="title">عنوان الاشعارات</label>
			    <input class="form-control col-md-8" list="items" name="n_item"> 
                    <datalist id="items">
                        <option value="الاخبار"></option>
                        <option value="الكمية و السعر"></option>
                    </datalist>
            </div>

          <div class="form-group row">
                <label class="col-md-2 text-right " for="text">محتوى الاشعار</label>
                <select class="form-control col-md-8" name="n_message">
                    <option value="تم اضافة خبر جديد"> تم اضافة خبر جديد</option>
                    <option value="تم تعديل سعر البنزين">تم تعديل سعر البنزين</option>
                    <option value="تم تعديل سعر الديزل">تم تعديل سعر الديزل</option>
                    <option value="تم تعديل الكميات">تم تعديل الكميات</option>
                    <option value="تم اضافة محطة جديدة">تم اضافة محطة جديدة</option>
                    <option value="تم تعديل بيانات محطة">تم تعديل بيانات محطة</option>
                </select>
            </div>
   
            <button type="submit" class="btn btn-primary offset-md-2"><?php if ($edit == '1') echo 'Save Changes'; else echo 'اضافة اشعار'; ?></button>
        </div>
        <?php echo form_close();?>
    <!-- </form> -->
</div>
