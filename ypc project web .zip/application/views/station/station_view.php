
<?php if (null !== $this->session->flashdata('success_add')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('success_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('error_add')): ?>
	<div class="alert alert-warning  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('error_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
	<?php elseif (null !== $this->session->flashdata('updated')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('updated'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('deleted')): ?>
	<div class="alert alert-danger  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('deleted'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php endif;?>

<h2 class="text-center py-3">المحطات </h2>
<a href='<?php echo base_url('stations/add_station') ?>' class="btn btn-primary mb-2">اضافة محطة</a>

<table class="table table-dark text-center">
<thead>
	<tr>
	    <th scope="col">رقم الادمن</th>
		<th scope="col">اسم المحطة</th>
		<th scope="col">نوع المحطة</th>
		<th scope="col">حالة المحطة</th>
		<th scope="col">عنوان المحطة</th>
		<th scope="col">خطوط العرض</th>
		<th scope="col">خطوط الطول</th>
		<th scope="col">الصلاحيات</th>
	</tr>
</thead>
<tbody>
	<?php foreach($station_data as $station): ?>
	<tr>
	    <td><?= $station->m_id; ?></td>
		<td><?= $station->s_name; ?></td>
		<td><?= $station->s_type; ?></td>
		<td><?= $station->s_status; ?></td>
		<td><?= $station->s_address; ?></td>
		<td><?= $station->s_latitude; ?></td>
		<td><?= $station->s_longitude; ?></td>
		<td>
			<a href="<?php echo base_url().'stations/edit_station/'. $station->s_id ?>" class="btn btn-success">تعديل</a>
			<a href="<?php echo base_url().'stations/delete_station/'. $station->s_id ?>" class="btn btn-danger">حذف</a>
		</td>
	</tr>
	<?php endforeach;?>
</tbody>
</table>
