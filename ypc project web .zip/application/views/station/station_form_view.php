<div class="text-center w-100 mb-5">
    <h1 class="py-4"><?php echo $edit == '1' ? 'تعديل محطة' : 'اضافة محطة' ?></h1>
</div>
<div class="w-75 m-auto">
    <?php echo form_open_multipart( $edit == 1 ? base_url('Stations/edit_station/' . $station->s_id . '') : base_url('stations/add_station') );?>
        <div class="station-form">
            <div class="form-group row">
                <label class="col-md-2 text-right " for="name">اسم المحطة</label>
                <input type="text" class="form-control col-md-8" name="name" 
                    value="<?php if(isset($name)){echo $name;} elseif(isset($station)) {echo $station->s_name;} else {echo '';} ?>">
                <?php if (form_error('name')) { ?>
                    <div class="alert alert-danger  offset-md-2 col-md-8" role="alert">
                        <?= form_error('name','<p class="d-inline">','</p>') ?>                        
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span> 
                    </div>
                <?php } ?>
            </div>
            <div class="form-group row">
                <label class="col-md-2 text-right " for="s_type">نوع المحطة</label>
                <input type="text" class="form-control col-md-8" name="s_type" 
                    value="<?php if(isset($s_type)){echo $s_type;} elseif(isset($station)) {echo $station->s_type;} else {echo '';} ?>">
                <?php if (form_error('s_type')) { ?>
                    <div class="alert alert-danger  offset-md-2 col-md-8" role="alert">
                        <?= form_error('s_type','<p class="d-inline">','</p>') ?>                        
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span> 
                    </div>
                <?php } ?>
            </div>

            <div class="form-group row">
                <label class="col-md-2 text-right " for="s_status">حالة المحطة</label>
                <select class="form-control col-md-8" name="s_status">
                    <option value="مفتوح">
                        مفتوح</option>
                    <option value="مغلق">
                        مغلق</option>
                </select>
            </div>

            <div class="form-group row">
                <label class="col-md-2 text-right " for="s_address">عنوان المحطة</label>
                <input type="text" class="form-control col-md-8" name="s_address" 
                    value="<?php if(isset($s_address)){echo $s_address;} elseif(isset($station)) {echo $station->s_address;} else {echo '';} ?>">
                    
                <?php if (form_error('s_address')) { ?>
                    <div class="alert alert-danger  offset-md-2 col-md-8" role="alert">
                        <?= form_error('s_address','<p class="d-inline">','</p>') ?>                        
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span> 
                    </div>
                <?php } ?>
            </div>
            </div>

            <div class="form-group row">
                <label class="col-md-2 text-right " for="s_latitude">خطوط العرض</label>
                <input type="text" class="form-control col-md-8" name="s_latitude" 
                    value="<?php if(isset($s_latitude)){echo $s_latitude;} elseif(isset($station)) {echo $station->s_latitude;} else {echo '';} ?>">
                <?php if (form_error('s_latitude')) { ?>
                    <div class="alert alert-danger  offset-md-2 col-md-8" role="alert">
                        <?= form_error('s_latitude','<p class="d-inline">','</p>') ?>                        
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span> 
                    </div>
                <?php } ?>
            </div>

            <div class="form-group row">
                <label class="col-md-2 text-right " for="s_longitude">خطوط الطول</label>
                <input type="text" class="form-control col-md-8" name="s_longitude" 
                    value="<?php if(isset($s_longitude)){echo $s_longitude;} elseif(isset($station)) {echo $station->s_longitude;} else {echo '';} ?>">
                <?php if (form_error('s_longitude')) { ?>
                    <div class="alert alert-danger  offset-md-2 col-md-8" role="alert">
                        <?= form_error('s_longitude','<p class="d-inline">','</p>') ?>                        
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span> 
                    </div>
                <?php } ?>
            </div>


            <button type="submit" class="btn btn-primary offset-md-2"><?php if ($edit == '1') echo 'Save Changes'; else echo 'Add station'; ?></button>
        </div>
        <?php echo form_close();?>
    <!-- </form> -->
</div>
