
<div class="text-center w-100 mb-5">
    <h1 class="py-4"><?php echo $edit == '1' ? 'تعديل سعر او كمية' : 'اضافة سعر او كمية' ?></h1>
</div>
<div class="w-75 m-auto">
    <?php echo form_open_multipart( $edit == 1 ? base_url('Pricequantity/edit_pricequantity/'. $pricequantity->pq_id) : base_url('Pricequantity/add_pricequantity') );?>
        <div class="nav-form">
            <div class="form-group row">
                <label class="col-md-2 text-right " for="title">االسعر او الكمية</label>
				<input type="text" class="form-control col-md-8" name="pq_value" 
					value="<?php if(isset($Pricequantity)) {echo $Pricequantity->pq_value;} elseif(isset($pq_value)){echo $pq_value;} else {echo '';} ?>">
                <?php if (form_error('pq_value')) { ?>
                    <div class="alert alert-danger  offset-md-2 col-md-8" role="alert">
                        <?= form_error('pq_value','<p class="d-inline">','</p>') ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span> 
                    </div>
                <?php } ?>
            </div>

             <button type="submit" class="btn btn-primary offset-md-2"><?php if ($edit == '1') echo 'Save Changes'; else echo 'اضافة سعر او كمية'; ?></button> 
        </div>
        <?php echo form_close();?>
    <!-- </form> -->
</div>
