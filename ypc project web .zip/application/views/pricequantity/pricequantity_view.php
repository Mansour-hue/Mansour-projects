
<?php if (null !== $this->session->flashdata('success_add')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('success_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
	<?php elseif (null !== $this->session->flashdata('updated')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('updated'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('error_add')): ?>
	<div class="alert alert-warning  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('error_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('deleted')): ?>
	<div class="alert alert-danger  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('deleted'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php endif;?>

<h2 class="text-center py-3">الكميات و الاسعار</h2>
<!-- <a href='<?php echo base_url('news/add_news') ?>' class="btn btn-primary mb-2">Add news</a> -->

<table class="table table-dark text-center">
<thead>
	<tr>
	    <th scope="col">رقم الادمن</th>
		<th scope="col">الاسعار و الكميات</th>
		<th scope="col">الصلاحيات</th>

	</tr>
</thead>
<tbody>
	<?php foreach ($Pricequantity_data as $Priceq): ?>
    <tr>
      <td><?=$Priceq->m_id;?></td>
      <td><?=$Priceq->pq_value;?></td>
      <td>
      	<a href="<?php echo base_url() . 'Pricequantity/edit_pricequantity/' . $Priceq->pq_id ?>" class="btn btn-success">تعديل</a>
      </td>
    </tr>
	<?php endforeach;?>
 