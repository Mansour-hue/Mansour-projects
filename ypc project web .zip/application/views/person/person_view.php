
<?php if (null !== $this->session->flashdata('success_add')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('success_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('error_add')): ?>
	<div class="alert alert-warning  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('error_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('deleted')): ?>
	<div class="alert alert-danger  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('deleted'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php endif;?>

<h2 class="text-center py-3">User </h2>
<a href='<?php echo base_url('Persons/add_person') ?>' class="btn btn-primary mb-2">Add User</a>

<table class="table table-dark text-center">
<thead>
	<tr>
		<th scope="col">Fname</th>
		<th scope="col">Lname</th>
		<th scope="col">Password</th>
		<th scope="col">Email</th>
		<th scope="col">Manager ID</th>
		<th scope="col">User ID</th>
	</tr>
</thead>
<tbody>
	<?php foreach($persons_data as $person): ?>
	<tr>
	<td><?= $person->Fname; ?></td>
	<td><?= $person->Lname; ?></td>
	<td><?= $person->U_password; ?></td>
	<td><?= $person->Email; ?></td>
	<td><?= $person->M_ID; ?></td>
	<td><?= $person->U_ID; ?></td>
	<td>
		<a href="<?php echo base_url().'Persons/edit_person/'. $person->U_ID ?>" class="btn btn-success">Edit</a>
		<a href="<?php echo base_url().'Persons/delete_person/'. $person->U_ID ?>" class="btn btn-danger">Delete</a>
	</td>
	</tr>
	<?php endforeach;?>
</tbody>
</table>
