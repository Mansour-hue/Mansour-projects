


<?php if (null !== $this->session->flashdata('success_add')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('success_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('error_add')): ?>
	<div class="alert alert-warning  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('error_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('updated')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('updated'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('deleted')): ?>
	<div class="alert alert-danger  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('deleted'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>

<?php endif;?>

<h2 class="text-center py-3">مدير النظام </h2>
<a href='<?php echo base_url('Users/register') ?>' class="btn btn-primary mb-2">اضافة مدير </a>

<table id="datatable_tbl" class="table table-dark text-center display"  >
	<thead>
		<tr>
		    <th scope="col">رقم الادمن</th>
			<th scope="col">الاسم</th>
			<th scope="col">الايميل</th>
			<th scope="col">الصلاحيات</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($users as $user): ?>
		<tr>
		    <td><?=$user->M_ID;?></td>
			<td><?=$user->name;?></td>
			<td><?=$user->email;?></td>
			<td>
				<a href="<?php echo base_url() . 'users/user_delete/' . $user->M_ID ?>" class="btn btn-danger">حذف</a>
			</td>
		</tr>
		<?php endforeach;?>
	</tbody>
</table>

