


<?php if (null !== $this->session->flashdata('success_add')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('success_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('error_add')): ?>
	<div class="alert alert-warning  offset-md-2 col-md-10" role="alert">
		<?php echo $this->session->flashdata('error_add'); ?>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('updated')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('updated'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('deleted')): ?>
	<div class="alert alert-danger  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('deleted'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('logeding')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('logeding'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php elseif (null !== $this->session->flashdata('registerd')): ?>
	<div class="alert alert-success  offset-md-2 col-md-10" role="alert">
	<?php echo $this->session->flashdata('registerd'); ?>
	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	<span aria-hidden="true">&times;</span>
	</div>
<?php endif;?>

<h2 class="text-center py-3">البلاغات </h2>
<!-- <a href='<?php echo base_url('Reports/add_reports') ?>' class="btn btn-primary mb-2">Add new</a> -->

<table id="datatable_tbl" class="table table-dark text-center display"  >
	<thead>
		<tr>
			<th scope="col">الجهة المستهدفة</th>
			<th scope="col">نوع البلاغ</th>
			<th scope="col">مكان البلاغ</th>
			<th scope="col">صورة البلاغ</th>
			<th scope="col">عنوان جهار المبلغ</th>
			<th scope="col">تاريخ البلاغ</th>
		</tr>
	</thead>
	<tbody><!-- <img src="<?= base_url('files/imgs/reports images/' . $report->report_image )?>" alt=""> -->
		<?php foreach ($reports_data as $report): ?>
		<tr>
			<td><?=$report->report_target;?></td>
			<td><?=$report->report_type;?></td>
			<td><?=$report->report_street;?></td>
			<td><?php echo '<img src="data:image/jpeg;base64,'.base64_encode($report->report_image).'"'; ?></td>
			<td><?=$report->report_device_id;?></td>
			<td><?=$report->report_date;?></td>
			<td>
				<a href="<?php echo base_url() . 'Reports/delete_report/' . $report->report_id ?>" class="btn btn-danger">الحذف</a>
			</td>
		</tr>
		<?php endforeach;?>
	</tbody>
</table>

